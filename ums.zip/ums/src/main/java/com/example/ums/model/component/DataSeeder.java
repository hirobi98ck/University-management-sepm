package com.example.ums.model.component;

import com.example.ums.model.entity.Role;
import com.example.ums.model.entity.User;
import com.example.ums.model.repository.UserRepository;
import com.example.ums.model.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Creates one demo account per role the first time the app starts. */
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final UserService users;
    private final UserRepository repo;

    @Override
    public void run(String... args) {
        seed(Role.ADMIN, "System Admin", "admin@kuet.ac.bd", "admin123", null, null, null);
        seed(Role.TEACHER, "Demo Teacher", "teacher@kuet.ac.bd", "teacher123", "CSE", null, "Lecturer");
        seed(Role.STUDENT, "Demo Student", "student@kuet.ac.bd", "student123", "CSE", "2307001", null);
    }

    private void seed(Role role, String name, String email, String password,
                      String department, String roll, String designation) {
        if (repo.existsByEmail(email)) return;
        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setPassword(password);
        u.setDepartment(department);
        u.setRoll(roll);
        u.setDesignation(designation);
        users.create(role, u);
    }
}
