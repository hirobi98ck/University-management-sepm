package com.example.ums.model.entity;

public enum Role { ADMIN, TEACHER, STUDENT }
