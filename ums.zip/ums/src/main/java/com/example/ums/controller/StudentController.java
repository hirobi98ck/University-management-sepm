package com.example.ums.controller;

import com.example.ums.model.entity.Role;
import com.example.ums.model.entity.User;
import com.example.ums.model.service.UserService;
import java.security.Principal;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Student dashboard: a student can manage students only. */
@Controller
@RequestMapping("/student")
@RequiredArgsConstructor
public class StudentController {

    private static final String HOME = "/student/dashboard";

    private final UserService users;

    @GetMapping("/dashboard")
    public String dashboard(@RequestParam(required = false) Long edit, Principal p, Model m) {
        m.addAttribute("me", users.byEmail(p.getName()));
        m.addAttribute("students", users.list(Role.STUDENT));
        m.addAttribute("editing", edit == null ? null
                : users.find(edit).filter(u -> u.getRole() == Role.STUDENT).orElse(null));
        return "student/dashboard";
    }

    @PostMapping("/users")
    public String create(@ModelAttribute User form, RedirectAttributes ra) {
        return Flash.run(ra, "Student created", HOME, HOME, () -> users.create(Role.STUDENT, form));
    }

    @PostMapping("/users/{id}/update")
    public String update(@PathVariable Long id, @ModelAttribute User form, Principal p, RedirectAttributes ra) {
        return Flash.run(ra, "Student updated", HOME, HOME + "?edit=" + id,
                () -> users.update(Role.STUDENT, id, form, p.getName()));
    }

    @PostMapping("/users/{id}/delete")
    public String delete(@PathVariable Long id, Principal p, RedirectAttributes ra) {
        return Flash.run(ra, "Student deleted", HOME, HOME,
                () -> users.delete(Role.STUDENT, id, p.getName()));
    }
}
