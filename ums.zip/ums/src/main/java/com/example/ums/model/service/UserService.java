package com.example.ums.model.service;

import com.example.ums.model.entity.Role;
import com.example.ums.model.entity.User;
import com.example.ums.model.repository.UserRepository;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
public class UserService {

    private static final int MIN_PASSWORD = 6;

    private final UserRepository repo;
    private final PasswordEncoder encoder;

    // ---------- create ----------
    public User create(Role role, User in) {
        if (role == null) throw bad("Role is required");
        if (isBlank(in.getName())) throw bad("Name is required");
        if (isBlank(in.getEmail())) throw bad("Email is required");
        checkPassword(in.getPassword());

        String email = normalize(in.getEmail());
        if (repo.existsByEmail(email)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already exists");

        User u = new User();
        u.setRole(role);
        u.setName(in.getName().trim());
        u.setEmail(email);
        u.setPassword(encoder.encode(in.getPassword()));
        applyProfile(u, in);
        return repo.save(u);
    }

    // ---------- read ----------
    public List<User> list(Role role) {
        return repo.findByRoleOrderByIdAsc(role);
    }

    /** Finds a user, but only if he/she belongs to the given resource (role). */
    public User get(Role role, Long id) {
        return repo.findByIdAndRole(id, role)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, role.name().toLowerCase() + " not found"));
    }

    public User byId(Long id) {
        return repo.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
    }

    public Optional<User> find(Long id) {
        return repo.findById(id);
    }

    public User byEmail(String email) {
        return repo.findByEmail(normalize(email))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
    }

    // ---------- update (only the fields that are sent are changed) ----------
    public User update(Role role, Long id, User in, String actingEmail) {
        User u = get(role, id);

        if (in.getName() != null) {
            if (isBlank(in.getName())) throw bad("Name cannot be empty");
            u.setName(in.getName().trim());
        }
        if (in.getEmail() != null) {
            if (isBlank(in.getEmail())) throw bad("Email cannot be empty");
            String email = normalize(in.getEmail());
            // the logged-in session is tied to the email, so changing your own would break it
            if (u.getEmail().equalsIgnoreCase(actingEmail) && !email.equals(u.getEmail()))
                throw new ResponseStatusException(HttpStatus.CONFLICT, "You cannot change your own email while logged in");
            repo.findByEmail(email)
                    .filter(other -> !other.getId().equals(id))
                    .ifPresent(other -> { throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already exists"); });
            u.setEmail(email);
        }
        if (!isBlank(in.getPassword())) {
            checkPassword(in.getPassword());
            u.setPassword(encoder.encode(in.getPassword()));
        }
        applyProfile(u, in);
        return repo.save(u);
    }

    // ---------- delete ----------
    public void delete(Role role, Long id, String actingEmail) {
        User u = get(role, id);
        if (u.getEmail().equalsIgnoreCase(actingEmail))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "You cannot delete your own account");
        repo.delete(u);
    }

    // ---------- helpers ----------
    private void applyProfile(User u, User in) {
        if (in.getDepartment() != null) u.setDepartment(clean(in.getDepartment()));
        if (in.getRoll() != null && u.getRole() == Role.STUDENT) u.setRoll(clean(in.getRoll()));
        if (in.getDesignation() != null && u.getRole() == Role.TEACHER) u.setDesignation(clean(in.getDesignation()));
    }

    private void checkPassword(String raw) {
        if (raw == null || raw.length() < MIN_PASSWORD)
            throw bad("Password must be at least " + MIN_PASSWORD + " characters");
    }

    private static String normalize(String email) { return email.trim().toLowerCase(); }
    private static boolean isBlank(String s) { return s == null || s.isBlank(); }
    private static String clean(String s) { return s == null || s.isBlank() ? null : s.trim(); }
    private static ResponseStatusException bad(String msg) { return new ResponseStatusException(HttpStatus.BAD_REQUEST, msg); }
}
