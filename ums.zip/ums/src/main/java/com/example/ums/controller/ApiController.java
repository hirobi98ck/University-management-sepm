package com.example.ums.controller;

import com.example.ums.model.entity.Role;
import com.example.ums.model.entity.User;
import com.example.ums.model.service.UserService;
import java.net.URI;
import java.security.Principal;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * JSON REST API.
 *   /api/admins    -> ADMIN only
 *   /api/teachers  -> ADMIN, TEACHER
 *   /api/students  -> ADMIN, STUDENT
 * (the access rules live in SecurityConfig)
 */
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ApiController {

    private final UserService users;

    // ---------- current user ----------
    @GetMapping("/me")
    public User me(Principal principal) {
        return users.byEmail(principal.getName());
    }

    // ---------- admins ----------
    @GetMapping("/admins")
    public List<User> listAdmins() { return users.list(Role.ADMIN); }

    @GetMapping("/admins/{id}")
    public User getAdmin(@PathVariable Long id) { return users.get(Role.ADMIN, id); }

    @PostMapping("/admins")
    public ResponseEntity<User> createAdmin(@RequestBody User body) { return created(Role.ADMIN, "admins", body); }

    @PutMapping("/admins/{id}")
    public User updateAdmin(@PathVariable Long id, @RequestBody User body, Principal p) {
        return users.update(Role.ADMIN, id, body, p.getName());
    }

    @DeleteMapping("/admins/{id}")
    public ResponseEntity<Void> deleteAdmin(@PathVariable Long id, Principal p) { return removed(Role.ADMIN, id, p); }

    // ---------- teachers ----------
    @GetMapping("/teachers")
    public List<User> listTeachers() { return users.list(Role.TEACHER); }

    @GetMapping("/teachers/{id}")
    public User getTeacher(@PathVariable Long id) { return users.get(Role.TEACHER, id); }

    @PostMapping("/teachers")
    public ResponseEntity<User> createTeacher(@RequestBody User body) { return created(Role.TEACHER, "teachers", body); }

    @PutMapping("/teachers/{id}")
    public User updateTeacher(@PathVariable Long id, @RequestBody User body, Principal p) {
        return users.update(Role.TEACHER, id, body, p.getName());
    }

    @DeleteMapping("/teachers/{id}")
    public ResponseEntity<Void> deleteTeacher(@PathVariable Long id, Principal p) { return removed(Role.TEACHER, id, p); }

    // ---------- students ----------
    @GetMapping("/students")
    public List<User> listStudents() { return users.list(Role.STUDENT); }

    @GetMapping("/students/{id}")
    public User getStudent(@PathVariable Long id) { return users.get(Role.STUDENT, id); }

    @PostMapping("/students")
    public ResponseEntity<User> createStudent(@RequestBody User body) { return created(Role.STUDENT, "students", body); }

    @PutMapping("/students/{id}")
    public User updateStudent(@PathVariable Long id, @RequestBody User body, Principal p) {
        return users.update(Role.STUDENT, id, body, p.getName());
    }

    @DeleteMapping("/students/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id, Principal p) { return removed(Role.STUDENT, id, p); }

    // ---------- helpers ----------
    // The role always comes from the URL, never from the request body,
    // so nobody can create an admin by posting to /api/students.
    private ResponseEntity<User> created(Role role, String resource, User body) {
        User saved = users.create(role, body);
        return ResponseEntity.created(URI.create("/api/" + resource + "/" + saved.getId())).body(saved);
    }

    private ResponseEntity<Void> removed(Role role, Long id, Principal acting) {
        users.delete(role, id, acting.getName());
        return ResponseEntity.noContent().build();
    }
}
