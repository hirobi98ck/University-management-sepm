package com.example.ums.model.repository;

import com.example.ums.model.entity.Role;
import com.example.ums.model.entity.User;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);
    List<User> findByRoleOrderByIdAsc(Role role);
    Optional<User> findByIdAndRole(Long id, Role role);
}
