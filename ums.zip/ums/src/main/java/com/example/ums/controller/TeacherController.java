package com.example.ums.controller;

import com.example.ums.model.entity.Role;
import com.example.ums.model.entity.User;
import com.example.ums.model.service.UserService;
import java.security.Principal;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Teacher dashboard: a teacher can manage teachers only. */
@Controller
@RequestMapping("/teacher")
@RequiredArgsConstructor
public class TeacherController {

    private static final String HOME = "/teacher/dashboard";

    private final UserService users;

    @GetMapping("/dashboard")
    public String dashboard(@RequestParam(required = false) Long edit, Principal p, Model m) {
        m.addAttribute("me", users.byEmail(p.getName()));
        m.addAttribute("teachers", users.list(Role.TEACHER));
        m.addAttribute("editing", edit == null ? null
                : users.find(edit).filter(u -> u.getRole() == Role.TEACHER).orElse(null));
        return "teacher/dashboard";
    }

    @PostMapping("/users")
    public String create(@ModelAttribute User form, RedirectAttributes ra) {
        return Flash.run(ra, "Teacher created", HOME, HOME, () -> users.create(Role.TEACHER, form));
    }

    @PostMapping("/users/{id}/update")
    public String update(@PathVariable Long id, @ModelAttribute User form, Principal p, RedirectAttributes ra) {
        return Flash.run(ra, "Teacher updated", HOME, HOME + "?edit=" + id,
                () -> users.update(Role.TEACHER, id, form, p.getName()));
    }

    @PostMapping("/users/{id}/delete")
    public String delete(@PathVariable Long id, Principal p, RedirectAttributes ra) {
        return Flash.run(ra, "Teacher deleted", HOME, HOME,
                () -> users.delete(Role.TEACHER, id, p.getName()));
    }
}
