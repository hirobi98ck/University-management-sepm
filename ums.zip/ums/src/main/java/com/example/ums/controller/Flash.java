package com.example.ums.controller;

import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Tiny helper: runs an action and turns its result/error into a flash message + redirect. */
final class Flash {
    private Flash() {}

    static String run(RedirectAttributes ra, String okMessage, String okPath, String errorPath, Runnable action) {
        try {
            action.run();
            ra.addFlashAttribute("ok", okMessage);
            return "redirect:" + okPath;
        } catch (ResponseStatusException e) {
            String reason = e.getReason() != null ? e.getReason() : e.getStatusCode().toString();
            ra.addFlashAttribute("error", reason);
            return "redirect:" + errorPath;
        }
    }
}
