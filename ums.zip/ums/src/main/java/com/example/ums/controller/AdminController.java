package com.example.ums.controller;

import com.example.ums.model.entity.Role;
import com.example.ums.model.entity.User;
import com.example.ums.model.service.UserService;
import java.security.Principal;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Admin dashboard: manages admins, teachers and students. */
@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private static final String HOME = "/admin/dashboard";

    private final UserService users;

    @GetMapping("/dashboard")
    public String dashboard(@RequestParam(required = false) Long edit, Principal p, Model m) {
        m.addAttribute("me", users.byEmail(p.getName()));
        m.addAttribute("admins", users.list(Role.ADMIN));
        m.addAttribute("teachers", users.list(Role.TEACHER));
        m.addAttribute("students", users.list(Role.STUDENT));
        m.addAttribute("editing", edit == null ? null : users.find(edit).orElse(null));
        return "admin/dashboard";
    }

    @PostMapping("/users")
    public String create(@ModelAttribute User form, RedirectAttributes ra) {
        return Flash.run(ra, "User created", HOME, HOME, () -> users.create(form.getRole(), form));
    }

    @PostMapping("/users/{id}/update")
    public String update(@PathVariable Long id, @ModelAttribute User form, Principal p, RedirectAttributes ra) {
        return Flash.run(ra, "User updated", HOME, HOME + "?edit=" + id,
                () -> users.update(users.byId(id).getRole(), id, form, p.getName()));
    }

    @PostMapping("/users/{id}/delete")
    public String delete(@PathVariable Long id, Principal p, RedirectAttributes ra) {
        return Flash.run(ra, "User deleted", HOME, HOME,
                () -> users.delete(users.byId(id).getRole(), id, p.getName()));
    }
}
